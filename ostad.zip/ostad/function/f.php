<?php

$fileName = 'test.txt';
$fp = fopen($filename, "w");







$data = [
    "id" => 'dd',
    "userName" => 'maraz',
    "email" => 'maraz53334@gmail.com',
    "password" => 'ff',
    "date" => '11/12/2023',
    "role" => 'user',
];
$seri = serialize($data);
print_r($seri);