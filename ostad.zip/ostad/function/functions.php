<?php
// generate User unique Number;
function generateUniqueNumber()
{
    $num = rand(000, 999);
    $fileName = "data.txt";
    $fp = fopen($fileName, "r");
    $inCorrect = 'notFound';
    while ($data = fgetcsv($fp)) {
        if ($data[0] == $num) {
            $inCorrect =  'found';
        }
    }
    if ($inCorrect != 'found') {
        return $num;
    } else {
        generateUniqueNumber();
    }
}
// registration process;
if (isset($_POST['registerBtn'])) {
    // connect file;
    $fileName = 'data.txt';
    // stor data in variable;
    $userName   = $_POST['userName'];
    $email      = $_POST['email'];
    $password   = $_POST['password'];
    $isError    = false;
    // check data is empty or not;
    if (empty($userName)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'User Name Is Required');";
        header("Location: register");
        exit;
    } else {
        $_SESSION['provitedUserName'] = $userName;
    }
    if (empty($email)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Email Is Required');";
        header("Location: register");
        exit;
    } else {
        $_SESSION['provitedEmail'] = $email;
    }
    if (empty($password)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Password Is Required');";
        header("Location: register");
        exit;
    } else {
        $password = sha1(base64_encode(md5(base64_encode($password))));
    }
    // check email is already exist or not;
    $eamilFound = "notfound";
    $fp = fopen($fileName, "r");
    while ($data = fgetcsv($fp)) {
        if ($data[1] === $email) {
            $eamilFound = "found";
        }
    }
    if ($eamilFound != "found") {
        $date = date("Y-m-d H:i:s A");
        // input data in file;
        $data = [
            "id" => generateUniqueNumber(),
            "userName" => $userName,
            "email" => $email,
            "password" => $password,
            "date" => $date,
            "role" => 'user',
        ];
        $fp = fopen($fileName, "a+");
        fputcsv($fp, $data);
        fclose($fp);
        $_SESSION['allFildsAreRequired'] = "errorMessage('success', 'Successfully Register');";
        $_SESSION['LoginStatus'] = 'success';
        unset($_SESSION['provitedUserName']);
        unset($_SESSION['provitedEmail']);
        header("Location: register");
        exit;
    } else {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Email Is Already Added');";
        header("Location: register");
        exit;
    }
}
// login process;
if (isset($_POST["loginBtn"])) {
    // stor data in variable;
    $email      = $_POST["email"];
    $password   = $_POST["password"];
    $fileName   = 'data.txt';
    // check empty or not;
    if (empty($email)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Email Is Required!');";
        header("Location: login");
        exit;
    } else {
        $_SESSION['provitedEmail'] = $email;
    }
    if (empty($password)) {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Password Is Required!');";
        header("Location: login");
        exit;
    } else {
        $password = sha1(base64_encode(md5(base64_encode($password))));
    }
    // check email & password match or not;
    $file = fopen($fileName, "r");
    while ($data = fgetcsv($file)) {
        if ($data[2] === $email && $data[3] === $password) {
            $isCorrct = "found";
        }
    }
    if ($isCorrct == "found") {
        $file = fopen($fileName, "r");
        while (($line = fgets($file)) != false) {
            $data = explode(",", $line);
            if (isset($data[2]) && trim($data[2]) === $email) {
                $_SESSION['UserId'] = $data[0];
                $_SESSION['UserName'] = $data[1];
                $_SESSION['UserRole'] = $data[5];
                break;
            }
        }
        $ff  = $_SESSION['UserRole'];
        // echo gettype($_SESSION['UserRole']);
        // var_dump($_SESSION['UserRole'] == 'user');
        if ($ff == 'user') {
            echo $_SESSION['UserRole'];
            header("Location: 404.php");
        } else if ($ff == 'manager') {
            echo $_SESSION['UserRole'];
            header("Location: manager/dashbaord.php");
        } elseif ($ff == 'admin') {
            echo $_SESSION['UserRole'];
            echo $data[5];
            header("Location: admin/dashboard.php");
        }else{
            echo 'done';
            exit;
        }
    } else {
        $_SESSION['allFildsAreRequired'] = "errorMessage('error', 'Incorrect Email & Password!');";
        header("Location: login.php");
        exit;
    }
}
